class FTexts {
  //will add letter comminly use messages here
  static const String serviceErrorMessage =
      "Error occured while fetching the request";
}
