// ignore_for_file: prefer_const_constructors, prefer_typing_uninitialized_variables, non_constant_identifier_names, prefer_const_literals_to_create_immutables, unnecessary_cast

import 'package:amigo_mobile_app/common/widgets/label_value_widget.dart';
import 'package:amigo_mobile_app/features/iSAC/models/vendor_req_details_response.dart';
import 'package:amigo_mobile_app/utility/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class AuditListWidget extends StatelessWidget {
  const AuditListWidget({
    super.key,
    required this.auditTrail,
  });

  //final ISACRequestDetailsClass AuditDetails;
  final List<AuditTrail> auditTrail;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: EdgeInsets.zero,
      scrollDirection: Axis.vertical,
      itemCount: auditTrail.length,
      shrinkWrap: true,
      itemBuilder: (context, index) {
        return AuditTrailView(
          auditTrail: auditTrail[index],
        );
      },
    );
  }
}

class AuditTrailView extends StatelessWidget {
  const AuditTrailView({super.key, required this.auditTrail});

  final AuditTrail auditTrail;

  @override
  Widget build(BuildContext context) {
    //bool isSubmitted = auditTrail.stage!.toLowerCase().contains("submitted");
    bool isrejected = auditTrail.stage!.toLowerCase().contains("rejected");

    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // SizedBox(
        //   height: 20,
        // ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                  isrejected
                      ? FontAwesomeIcons.solidCircleXmark
                      : FontAwesomeIcons.solidCircleCheck,
                  size: 30,
                  color: isrejected
                      ? FColors.rejecttextpanelcolor
                      : FColors.approvetextpanelcolor),
              SizedBox(width: 10),
              Text(auditTrail.stage.toString(),
                  textAlign: TextAlign.start,
                  style: const TextStyle(
                      fontWeight: FontWeight.w600,
                      color: FColors.textPrimary,
                      fontSize: 16))
            ],
          ),
        ),
        SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 12.0),
              child: Container(
                height: 90,
                width: 2,
                color: FColors.textSecondary,
                padding: EdgeInsets.only(left: 15, right: 15),
              ),
            ),
            SizedBox(width: 12),
            Padding(
              padding: const EdgeInsets.only(right: 12.0),
              child: SizedBox(
                width: MediaQuery.of(context).size.width - 55,
                child: Card(
                    child: Column(
                  children: [
                    LabelValueWidget(
                      label: 'Action By',
                      value: auditTrail.actionBy ?? "NA",
                      padding: const EdgeInsets.all(5),
                    ),
                    // const Divider(),
                    LabelValueWidget(
                      label: 'Action Date',
                      value: auditTrail.actionDate ?? "NA",
                      padding: const EdgeInsets.all(5),
                    )
                  ],
                )),
              ),
            ),
          ],
        ),
        SizedBox(height: 12),
      ],
    );
  }
}
