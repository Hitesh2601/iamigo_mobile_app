import 'dart:io';

import 'package:amigo_mobile_app/common/controller/dependency_injection.dart';
import 'package:amigo_mobile_app/features/iApproval/providers/fpn_tco_detail_provider.dart';
import 'package:amigo_mobile_app/features/iCart/providers/hardware_detail_provider.dart';
import 'package:amigo_mobile_app/features/iCart/providers/icart_filter_provider.dart';
import 'package:amigo_mobile_app/features/iCart/providers/icart_provider.dart';
import 'package:amigo_mobile_app/features/iSAC/providers/isac_provider.dart';
import 'package:amigo_mobile_app/features/iSAC/providers/isac_request_list_provider.dart';
import 'package:amigo_mobile_app/features/iSAC/providers/vendor_code_list_provider.dart';
import 'package:amigo_mobile_app/features/iSAC/providers/vendor_onboarding_list_provider.dart';
import 'package:amigo_mobile_app/features/iSAC/screens/dashboard/isac_dashboard_screen.dart';
import 'package:amigo_mobile_app/features/user/providers/login_provider.dart';
import 'package:amigo_mobile_app/splash_screen.dart';
import 'package:amigo_mobile_app/utility/constants/session.dart';
import 'package:amigo_mobile_app/utility/network/my_http_overrides.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
      overlays: [SystemUiOverlay.top]);
  SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(systemNavigationBarColor: Colors.transparent));
  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  HttpOverrides.global = MyHttpOverrides();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: ((context) => LoginProvider())),
        ChangeNotifierProvider(create: ((context) => ISACProvider())),
        ChangeNotifierProvider(create: ((context) => ICartProvider())),
        ChangeNotifierProvider(create: ((context) => ICartFilterProvider())),
        ChangeNotifierProvider(create: ((context) => HardwareDetailProvider())),
        ChangeNotifierProvider(create: ((context) => FpnTcoDetailProvider())),
        ChangeNotifierProvider(create: (context) => SelectedContainerIndex()),
        ChangeNotifierProvider(create: (context) => ScrollPositonNotifier()),
        ChangeNotifierProvider(create: (context) => ScrollProvider()),
        ChangeNotifierProvider(
            create: ((context) => ISACRequestListProvider())),
        ChangeNotifierProvider(
            create: ((context) => VendorOnBoardingListProvider())),
        ChangeNotifierProvider(create: ((context) => VendorCodeListProvider())),

        // ChangeNotifierProvider(create: (context) => ScrollNotifier()),
        ChangeNotifierProvider(create: (context) => ISACRejectListProvider()),
      ],
      child: const MyApp(),
    ),
  );
  DependencyInjection.init();
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // @override
  // void initState() async {
  //   super.initState();
  //   // if (await HelperFunctions.isRootOrJailbroken()) {
  //   //   HelperFunctions.showAlert("Security Alert",
  //   //       "Your device is rooted or jailbroken. Please remove jailbreak to use this app");
  //   //   exit(0);
  //   // }
  // }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (event) {
        SessionManagement.checkSession(context);
      },
      child: GetMaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'iAMIGO',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
          useMaterial3: true,
        ),
        home: const SplashScreen(),
      ),
    );
  }
}
